//
//  Palette.swift
//  ResertAI
//
//  Набори кольорів ("інгредієнти" фону) — фон + акцентний градієнт.
//  Користувач обирає один із них у Налаштуваннях, і весь інтерфейс
//  перефарбовується.
//

import SwiftUI

struct AppPalette: Identifiable, Hashable {
    let id: String
    let title: String
    let icon: String

    let lightTop: Color
    let lightBottom: Color
    let darkTop: Color
    let darkBottom: Color

    let accentA: Color
    let accentB: Color

    static func == (lhs: AppPalette, rhs: AppPalette) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

extension AppPalette {
    static let mint = AppPalette(
        id: "mint",
        title: "М'ята",
        icon: "leaf.fill",
        lightTop: Color(red: 0.90, green: 0.96, blue: 0.93),
        lightBottom: Color(red: 0.98, green: 0.98, blue: 0.965),
        darkTop: Color(red: 0.06, green: 0.09, blue: 0.08),
        darkBottom: Color(red: 0.03, green: 0.035, blue: 0.045),
        accentA: Color(red: 0.35, green: 0.47, blue: 1.0),
        accentB: Color(red: 0.42, green: 0.78, blue: 0.98)
    )

    static let sunset = AppPalette(
        id: "sunset",
        title: "Захід сонця",
        icon: "sun.horizon.fill",
        lightTop: Color(red: 1.0, green: 0.93, blue: 0.87),
        lightBottom: Color(red: 0.99, green: 0.97, blue: 0.95),
        darkTop: Color(red: 0.12, green: 0.06, blue: 0.06),
        darkBottom: Color(red: 0.05, green: 0.035, blue: 0.04),
        accentA: Color(red: 1.0, green: 0.45, blue: 0.42),
        accentB: Color(red: 1.0, green: 0.72, blue: 0.35)
    )

    static let ocean = AppPalette(
        id: "ocean",
        title: "Океан",
        icon: "water.waves",
        lightTop: Color(red: 0.85, green: 0.93, blue: 1.0),
        lightBottom: Color(red: 0.96, green: 0.98, blue: 0.99),
        darkTop: Color(red: 0.04, green: 0.08, blue: 0.13),
        darkBottom: Color(red: 0.02, green: 0.04, blue: 0.06),
        accentA: Color(red: 0.18, green: 0.55, blue: 0.95),
        accentB: Color(red: 0.25, green: 0.85, blue: 0.82)
    )

    static let lavender = AppPalette(
        id: "lavender",
        title: "Лаванда",
        icon: "sparkles",
        lightTop: Color(red: 0.93, green: 0.90, blue: 0.99),
        lightBottom: Color(red: 0.98, green: 0.97, blue: 0.99),
        darkTop: Color(red: 0.10, green: 0.07, blue: 0.14),
        darkBottom: Color(red: 0.045, green: 0.035, blue: 0.06),
        accentA: Color(red: 0.62, green: 0.42, blue: 0.98),
        accentB: Color(red: 0.93, green: 0.48, blue: 0.78)
    )

    static let slate = AppPalette(
        id: "slate",
        title: "Графіт",
        icon: "moon.stars.fill",
        lightTop: Color(red: 0.90, green: 0.91, blue: 0.93),
        lightBottom: Color(red: 0.97, green: 0.97, blue: 0.975),
        darkTop: Color(red: 0.07, green: 0.075, blue: 0.085),
        darkBottom: Color(red: 0.02, green: 0.022, blue: 0.026),
        accentA: Color(red: 0.32, green: 0.36, blue: 0.44),
        accentB: Color(red: 0.55, green: 0.60, blue: 0.68)
    )

    static let all: [AppPalette] = [.mint, .sunset, .ocean, .lavender, .slate]
}

/// Обчислені кольори інтерфейсу для поточної палітри. Ink/картки/тіні
/// однакові для всіх палітр — змінюється лише фон і акцентний градієнт.
struct RTheme {
    let palette: AppPalette

    var bgTop: Color { .adaptive(light: palette.lightTop, dark: palette.darkTop) }
    var bgBottom: Color { .adaptive(light: palette.lightBottom, dark: palette.darkBottom) }
    var accentA: Color { palette.accentA }
    var accentB: Color { palette.accentB }

    var ink: Color {
        .adaptive(
            light: Color(red: 0.11, green: 0.14, blue: 0.13),
            dark: Color(red: 0.95, green: 0.96, blue: 0.96)
        )
    }
    var inkMuted: Color {
        .adaptive(
            light: Color(red: 0.43, green: 0.47, blue: 0.46),
            dark: Color(red: 0.64, green: 0.67, blue: 0.67)
        )
    }
    var card: Color {
        .adaptive(light: .white, dark: Color(red: 0.11, green: 0.12, blue: 0.13))
    }
    var cardStroke: Color {
        .adaptive(light: Color.black.opacity(0.06), dark: Color.white.opacity(0.08))
    }
    var cardShadow: Color {
        .adaptive(light: Color.black.opacity(0.08), dark: Color.black.opacity(0.5))
    }

    var brandGradient: LinearGradient {
        LinearGradient(colors: [accentA, accentB], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    var backgroundGradient: LinearGradient {
        LinearGradient(colors: [bgTop, bgBottom], startPoint: .top, endPoint: .bottom)
    }
}

extension Color {
    /// Колір, що сам перемикається між світлим і темним варіантом
    /// залежно від поточної теми (системної або примусово заданої
    /// через .preferredColorScheme).
    static func adaptive(light: Color, dark: Color) -> Color {
        Color(UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(dark) : UIColor(light)
        })
    }
}

extension View {
    /// Поверхня елемента: на iOS 26+ — справжній Liquid Glass
    /// (`.glassEffect`), на старіших системах — попередній дизайн із
    /// непрозорою карткою й тонкою обвідкою. Один виклик покриває
    /// обидва випадки, тож рендер-код у самих екранах не дублюється.
    @ViewBuilder
    func glassSurface<S: Shape>(
        _ theme: RTheme,
        in shape: S,
        tinted: Bool = false,
        interactive: Bool = false
    ) -> some View {
        if #available(iOS 26.0, *) {
            let glass: Glass = tinted
                ? .regular.tint(theme.accentA)
                : .regular
            self.glassEffect(interactive ? glass.interactive() : glass, in: shape)
        } else {
            self
                .background(tinted ? AnyShapeStyle(theme.brandGradient) : AnyShapeStyle(theme.card), in: shape)
                .overlay(shape.stroke(theme.cardStroke, lineWidth: tinted ? 0 : 1))
        }
    }
}
