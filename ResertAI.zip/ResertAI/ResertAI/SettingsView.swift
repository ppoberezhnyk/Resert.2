//
//  SettingsView.swift
//  ResertAI
//
//  Налаштування: тема оформлення, палітра фону + локальний акаунт.
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        NavigationStack {
            ZStack {
                theme.backgroundGradient.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        themeSection
                        paletteSection

                        if settings.isLoggedIn {
                            accountSummarySection
                        } else {
                            AuthSection()
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Налаштування")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Готово") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    // MARK: Тема (світла/темна/система)

    private var themeSection: some View {
        SettingsCard(title: "Тема оформлення") {
            HStack(spacing: 10) {
                ForEach(AppTheme.allCases) { t in
                    ThemeOptionButton(
                        icon: t.icon,
                        title: t.title,
                        isSelected: settings.theme == t
                    ) {
                        withAnimation(.easeOut(duration: 0.2)) {
                            settings.theme = t
                        }
                    }
                }
            }
        }
    }

    // MARK: Палітра фону

    private var paletteSection: some View {
        SettingsCard(title: "Колір фону") {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 84), spacing: 10)], spacing: 10) {
                ForEach(AppPalette.all) { p in
                    PaletteOptionButton(
                        palette: p,
                        isSelected: settings.palette == p
                    ) {
                        withAnimation(.easeOut(duration: 0.2)) {
                            settings.palette = p
                        }
                    }
                }
            }
        }
    }

    // MARK: Акаунт (вже зареєстрований)

    private var accountSummarySection: some View {
        SettingsCard(title: "Акаунт") {
            HStack(spacing: 14) {
                Circle()
                    .fill(theme.brandGradient)
                    .frame(width: 46, height: 46)
                    .overlay(
                        Text(initials)
                            .font(.system(.headline, design: .rounded, weight: .bold))
                            .foregroundStyle(.white)
                    )

                VStack(alignment: .leading, spacing: 2) {
                    Text(settings.accountName.isEmpty ? "Без імені" : settings.accountName)
                        .font(.system(.body, design: .rounded, weight: .semibold))
                        .foregroundStyle(theme.ink)
                    Text(settings.accountEmail)
                        .font(.system(.footnote, design: .rounded))
                        .foregroundStyle(theme.inkMuted)
                }

                Spacer()
            }

            Button(role: .destructive) {
                settings.signOut()
            } label: {
                Text("Вийти")
                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.red.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.red)
            }
            .padding(.top, 4)
        }
    }

    private var initials: String {
        let parts = settings.accountName.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }
        return letters.isEmpty ? "?" : String(letters).uppercased()
    }
}

// MARK: - Картка-контейнер

private struct SettingsCard<Content: View>: View {
    @EnvironmentObject private var settings: SettingsStore
    let title: String
    @ViewBuilder let content: Content

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                .foregroundStyle(theme.inkMuted)

            content
        }
        .padding(16)
        .background(theme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(theme.cardStroke, lineWidth: 1)
        )
        .shadow(color: theme.cardShadow, radius: 8, y: 4)
    }
}

// MARK: - Кнопка вибору теми (світла/темна/система)

private struct ThemeOptionButton: View {
    @EnvironmentObject private var settings: SettingsStore
    let icon: String
    let title: String
    let isSelected: Bool
    let action: () -> Void

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .semibold))
                Text(title)
                    .font(.system(.caption, design: .rounded, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .foregroundStyle(isSelected ? .white : theme.ink)
            .background(
                isSelected ? AnyShapeStyle(theme.brandGradient) : AnyShapeStyle(theme.bgTop),
                in: RoundedRectangle(cornerRadius: 16, style: .continuous)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Кнопка вибору палітри фону

private struct PaletteOptionButton: View {
    let palette: AppPalette
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                ZStack {
                    LinearGradient(
                        colors: [palette.lightTop, palette.lightBottom],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .frame(height: 44)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [palette.accentA, palette.accentB],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 20, height: 20)
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(isSelected ? palette.accentA : Color.black.opacity(0.08), lineWidth: isSelected ? 2 : 1)
                )

                Text(palette.title)
                    .font(.system(.caption2, design: .rounded, weight: .medium))
                    .foregroundStyle(.primary)
            }
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Реєстрація / вхід

private struct AuthSection: View {
    @EnvironmentObject private var settings: SettingsStore

    private enum Mode: String, CaseIterable {
        case signIn = "Вхід"
        case register = "Реєстрація"
    }

    @State private var mode: Mode = .register
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorText: String?
    @State private var googleSetupHint: String?

    var body: some View {
        SettingsCard(title: "Акаунт") {
            Picker("", selection: $mode.animation()) {
                ForEach(Mode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)
            .padding(.bottom, 4)

            VStack(spacing: 10) {
                if mode == .register {
                    AuthField(icon: "person", placeholder: "Ім'я", text: $name)
                }
                AuthField(
                    icon: "envelope",
                    placeholder: "Пошта",
                    text: $email
                )
                AuthField(icon: "lock", placeholder: "Пароль", text: $password, isSecure: true)
                if mode == .register {
                    AuthField(icon: "lock.rotation", placeholder: "Підтвердіть пароль", text: $confirmPassword, isSecure: true)
                }
            }

            if let errorText {
                Text(errorText)
                    .font(.system(.footnote, design: .rounded))
                    .foregroundStyle(.red)
            }

            Button {
                submit()
            } label: {
                Text(mode == .register ? "Зареєструватися" : "Увійти")
                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .foregroundStyle(.white)
                    .background(RTheme(palette: settings.palette).brandGradient, in: RoundedRectangle(cornerRadius: 14))
            }
            .padding(.top, 6)

            Text("Дані зберігаються лише на цьому пристрої (локально), без сервера.")
                .font(.system(.caption2, design: .rounded))
                .foregroundStyle(RTheme(palette: settings.palette).inkMuted)
                .padding(.top, 2)

            HStack(spacing: 10) {
                VStack { Divider() }
                Text("або")
                    .font(.system(.caption2, design: .rounded))
                    .foregroundStyle(RTheme(palette: settings.palette).inkMuted)
                VStack { Divider() }
            }
            .padding(.vertical, 4)

            Button {
                signInWithGoogle()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "g.circle.fill")
                    Text("Увійти через Google")
                }
                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .foregroundStyle(RTheme(palette: settings.palette).ink)
                .background(RTheme(palette: settings.palette).card, in: RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(RTheme(palette: settings.palette).cardStroke, lineWidth: 1)
                )
            }

            if let googleSetupHint {
                Text(googleSetupHint)
                    .font(.system(.caption2, design: .rounded))
                    .foregroundStyle(.orange)
            }
        }
    }

    /// Поки Google Sign-In SDK не підключено (див. GoogleAuthService.swift),
    /// показуємо підказку замість реального входу. Після виконання кроків
    /// із коментаря в GoogleAuthService.swift заміни тіло цієї функції на
    /// виклик GoogleAuthService.signIn().
    private func signInWithGoogle() {
        googleSetupHint = "Google Sign-In ще не підключено. Відкрий GoogleAuthService.swift і виконай кроки 1–5 у коментарі зверху файлу."
    }

    private func submit() {
        errorText = nil
        let trimmedEmail = email.trimmingCharacters(in: .whitespaces)

        guard trimmedEmail.contains("@"), trimmedEmail.contains(".") else {
            errorText = "Введи коректну пошту."
            return
        }
        guard password.count >= 6 else {
            errorText = "Пароль має містити щонайменше 6 символів."
            return
        }

        if mode == .register {
            guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
                errorText = "Введи ім'я."
                return
            }
            guard password == confirmPassword else {
                errorText = "Паролі не збігаються."
                return
            }
            let cleanName = name.trimmingCharacters(in: .whitespaces)
            settings.register(name: cleanName, email: trimmedEmail)

            // Надсилаємо лист на щойно вказану пошту. Робимо це у
            // фоні — якщо EmailJS ще не налаштований або лист не
            // надійшов, реєстрація все одно успішна, це не блокує UI.
            Task {
                do {
                    try await EmailNotifier.sendWelcomeEmail(toName: cleanName, toEmail: trimmedEmail)
                } catch {
                    print("ResertAI: email-сповіщення не відправлено — \(error.localizedDescription)")
                }
            }
        } else {
            settings.signIn(email: trimmedEmail)
        }
    }
}

private struct AuthField: View {
    @EnvironmentObject private var settings: SettingsStore
    let icon: String
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var isSecure: Bool = false

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(theme.inkMuted)
                .frame(width: 18)

            Group {
                if isSecure {
                    SecureField(placeholder, text: $text)
                } else {
                    TextField(placeholder, text: $text)
                        .keyboardType(keyboard)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
            }
            .font(.system(.body, design: .rounded))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(theme.bgTop, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

#Preview {
    SettingsView()
        .environmentObject(SettingsStore())
}
