//
//  ResertAIApp.swift
//  ResertAI
//
//  Точка входу застосунку.
//

import SwiftUI

@main
struct ResertAIApp: App {
    @StateObject private var settings = SettingsStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .preferredColorScheme(settings.theme.colorScheme)
        }
    }
}
