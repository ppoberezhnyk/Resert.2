//
//  GoogleAuthService.swift
//  ResertAI
//
//  Обгортка над офіційним GoogleSignIn SDK для реальної реєстрації
//  через Google-акаунт.
//
//  ВАЖЛИВО, ЩОБ ЗАПРАЦЮВАЛО (усі кроки одноразові):
//
//  1. У Xcode: File → Add Package Dependencies… → встав адресу
//     https://github.com/google/GoogleSignIn-iOS → Add Package →
//     обери продукт "GoogleSignIn" для таргету ResertAI.
//
//  2. Створи OAuth Client ID:
//     - Йди на https://console.cloud.google.com
//     - Створи новий проєкт (або обери існуючий)
//     - APIs & Services → Credentials → Create Credentials →
//       OAuth client ID → тип "iOS"
//     - Bundle ID вкажи такий самий, як у Xcode → Signing & Capabilities
//       (зараз com.resertai.app)
//     - Скопіюй "Client ID" (виглядає як
//       123456-xxxx.apps.googleusercontent.com)
//
//  3. Встав Client ID у константу `clientID` нижче.
//
//  4. У Xcode: обери таргет ResertAI → вкладка Info → URL Types →
//     "+" → у поле URL Schemes встав свій Client ID, але ЗАДОМ
//     НАПЕРЕД (reversed), наприклад якщо Client ID —
//     "123456-xxxx.apps.googleusercontent.com", то URL Scheme —
//     "com.googleusercontent.apps.123456-xxxx".
//
//  5. Розкоментуй увесь код нижче (зараз він закоментований, щоб
//     проєкт компілювався одразу після завантаження, ще до того,
//     як ти додаси пакет).
//

import Foundation

/*
import GoogleSignIn
import UIKit

enum GoogleAuthError: Error, LocalizedError {
    case noRootViewController
    case missingProfile
    case cancelled

    var errorDescription: String? {
        switch self {
        case .noRootViewController:
            return "Не вдалося відкрити вікно входу Google."
        case .missingProfile:
            return "Google не повернув ім'я або пошту акаунту."
        case .cancelled:
            return "Вхід через Google скасовано."
        }
    }
}

@MainActor
enum GoogleAuthService {

    /// Встав сюди Client ID зі свого проєкту в Google Cloud Console.
    static let clientID = "ВСТАВ_CLIENT_ID.apps.googleusercontent.com"

    /// Викликати один раз при старті застосунку (у ResertAIApp.init).
    static func configure() {
        GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientID)
    }

    /// Обробка редиректу після входу — викликати з .onOpenURL у ResertAIApp.
    static func handle(url: URL) {
        GIDSignIn.sharedInstance.handle(url)
    }

    /// Показує екран входу Google і повертає ім'я та пошту акаунту.
    static func signIn() async throws -> (name: String, email: String) {
        guard let rootVC = UIApplication.shared.connectedScenes
            .compactMap({ ($0 as? UIWindowScene)?.keyWindow?.rootViewController })
            .first
        else {
            throw GoogleAuthError.noRootViewController
        }

        let result = try await GIDSignIn.sharedInstance.signIn(withPresenting: rootVC)
        guard let profile = result.user.profile else {
            throw GoogleAuthError.missingProfile
        }
        return (name: profile.name, email: profile.email)
    }

    static func signOut() {
        GIDSignIn.sharedInstance.signOut()
    }
}
*/
