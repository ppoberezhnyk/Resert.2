//
//  GroqAPIService.swift
//  ResertAI
//
//  Сервіс для звернення до Groq API — безкоштовний, без карти,
//  дуже швидкий (власні LPU-чипи), формат сумісний з OpenAI.
//
//  ВАЖЛИВО:
//  1. Встав свій API-ключ у константу `apiKey` нижче. Отримати можна
//     безкоштовно на https://console.groq.com/keys — вхід через
//     Google/GitHub або пошту, картка не потрібна.
//  2. НІКОЛИ не публікуй застосунок з ключем "в лоб" у продакшн /
//     App Store — ключ буде видно тому, хто розпакує .ipa. Для
//     реального релізу зроби простий бекенд-проксі, який ховає ключ
//     на сервері. Для особистого використання (збірка й встановлення
//     собі на телефон) так робити можна.
//  3. Безкоштовний рівень має денний ліміт запитів (оновлюється
//     щодня) — якщо застосунок почне відповідати помилкою 429, це
//     означає, що ліміт на сьогодні вичерпано.
//

import Foundation

enum GroqAPIError: Error, LocalizedError {
    case missingAPIKey
    case badResponse(String)
    case network(Error)
    case timedOut

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "Не вказано API-ключ. Відкрий GroqAPIService.swift і встав свій ключ у константу apiKey."
        case .badResponse(let msg):
            return "Помилка відповіді сервера: \(msg)"
        case .network(let err):
            return "Мережева помилка: \(err.localizedDescription)"
        case .timedOut:
            return "Режим \"Думає\" не встиг за 30 секунд. Спробуй ще раз або постав простіше запитання."
        }
    }
}

/// Два окремі режими роботи чат-бота.
enum ChatMode: String, CaseIterable, Identifiable {
    /// Звичайна швидка відповідь.
    case quick
    /// Розширене мислення — окрема reasoning-модель, що обмірковує
    /// відповідь довше (до ~30 секунд) перш ніж відповісти.
    case thinking

    var id: String { rawValue }

    var title: String {
        switch self {
        case .quick: return "Швидко"
        case .thinking: return "Думає"
        }
    }

    var icon: String {
        switch self {
        case .quick: return "bolt.fill"
        case .thinking: return "brain.head.profile"
        }
    }
}

final class GroqAPIService {

    // MARK: - Налаштування

    /// Встав сюди свій ключ Groq, наприклад: "gsk_...."
    private let apiKey: String = "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"

    /// Швидка модель для режиму "Швидко".
    private let quickModel: String = "openai/gpt-oss-20b"

    /// Reasoning-модель для режиму "Думає" — думає перед відповіддю.
    private let thinkingModel: String = "openai/gpt-oss-120b"

    /// Скільки максимум секунд чекати відповідь у режимі "Думає".
    private let thinkingTimeout: TimeInterval = 30

    private let endpoint = URL(string: "https://api.groq.com/openai/v1/chat/completions")!

    // MARK: - API

    struct ChatMessage {
        let role: String // "user" або "assistant"
        let content: String
    }

    struct Reply {
        let text: String
        /// Хід міркувань моделі — заповнено лише коли mode == .thinking.
        let thinking: String?
    }

    /// Надсилає всю історію діалогу та повертає відповідь асистента.
    /// У режимі .thinking запит автоматично обривається через ~30 сек,
    /// якщо модель не встигла відповісти.
    func sendMessage(history: [ChatMessage], mode: ChatMode) async throws -> Reply {
        guard !apiKey.isEmpty, apiKey != "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ" else {
            throw GroqAPIError.missingAPIKey
        }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

        var body: [String: Any] = [
            "messages": history.map { ["role": $0.role, "content": $0.content] }
        ]

        switch mode {
        case .quick:
            body["model"] = quickModel
            body["max_tokens"] = 1024
            request.timeoutInterval = 60
        case .thinking:
            body["model"] = thinkingModel
            body["max_tokens"] = 4096
            // "parsed" — Groq повертає хід міркувань окремим полем
            // reasoning, а не перемішує його з фінальною відповіддю.
            body["reasoning_format"] = "parsed"
            request.timeoutInterval = thinkingTimeout
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            let nsError = error as NSError
            if nsError.code == NSURLErrorTimedOut {
                throw GroqAPIError.timedOut
            }
            throw GroqAPIError.network(error)
        }

        guard let http = response as? HTTPURLResponse else {
            throw GroqAPIError.badResponse("Немає HTTP-відповіді")
        }

        guard (200...299).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "невідома помилка"
            throw GroqAPIError.badResponse("Код \(http.statusCode): \(text)")
        }

        guard
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let choices = json["choices"] as? [[String: Any]],
            let first = choices.first,
            let message = first["message"] as? [String: Any]
        else {
            throw GroqAPIError.badResponse("Не вдалося розпарсити відповідь")
        }

        var answerText = (message["content"] as? String) ?? ""
        var thinkingText = (message["reasoning"] as? String) ?? ""

        // Про всяк випадок: якщо reasoning-модель повернула хід
        // міркувань inline у <think>...</think> замість окремого поля.
        if thinkingText.isEmpty, let range = answerText.range(of: "</think>") {
            let think = answerText[answerText.startIndex..<range.upperBound]
            thinkingText = think
                .replacingOccurrences(of: "<think>", with: "")
                .replacingOccurrences(of: "</think>", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            answerText = String(answerText[range.upperBound...])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }

        let finalText = answerText.isEmpty ? "(порожня відповідь)" : answerText
        return Reply(text: finalText, thinking: thinkingText.isEmpty ? nil : thinkingText)
    }
}
