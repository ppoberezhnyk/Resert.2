//
//  Message.swift
//  ResertAI
//
//  Модель одного повідомлення в чаті.
//

import Foundation

struct Message: Identifiable, Equatable, Codable {
    enum Role: String, Codable {
        case user
        case assistant
    }

    let id: UUID
    let role: Role
    var text: String
    var isStreaming: Bool = false
    /// Хід міркувань моделі — заповнюється лише в режимі "Думає".
    var thinking: String? = nil

    init(id: UUID = UUID(), role: Role, text: String, isStreaming: Bool = false, thinking: String? = nil) {
        self.id = id
        self.role = role
        self.text = text
        self.isStreaming = isStreaming
        self.thinking = thinking
    }
}
